# Profile + Links Starter Kit (v2)

Now includes:
- Typography presets (Sans / Serif / Mono)
- Dark / Light toggle
- Simple structure for remixing

---

## Editing Your Site

Open `index.html` in a text editor.

### Change Your Name
Search for: `Your Name`

### Change Your Bio
Edit the paragraph under your name.

### Change Your Profile Image
Replace `profile.jpg` with your own image file.
Keep the same filename or update it in the HTML.

### Edit Your Links
Replace each `href="#"` with your actual URL.
Change the visible link text as needed.

### Update “Things I've Enjoyed Lately”
Replace the five placeholder links with things you’re currently enjoying.

---

## Changing Typography

At the top of the HTML file find:

<body class="preset-sans">

You can change it to:

preset-sans   → Clean default  
preset-serif  → More literary / classic  
preset-mono   → More DIY / code aesthetic  

Example:

<body class="preset-serif">

Save the file and refresh your browser.

---

## Uploading to Neocities

1. Create an account at https://neocities.org  
2. Log in → Dashboard → “Edit Site”  
3. Upload:
   - index.html
   - profile.jpg
   - favicon.png (optional)

4. Overwrite the existing index.html if prompted.

Your site will appear at:

https://yourusername.neocities.org

---

## Philosophy

One file.  
No frameworks.  
No tracking.  
Easy to understand.  
Easy to remix.  

Make it yours.
